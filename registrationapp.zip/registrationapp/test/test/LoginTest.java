/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package test;

import registrationapp.Login;


/**
 *
 * @author USER
 */
public class LoginTest {
    
  Login login = new Login();

    // assertEquals 

    
    public void testUserNameCorrect() {

        assertEquals("Username successfully captured.", login.checkUserName("kyl_1"));
    }

    
    public void testUserNameIncorrect() {

        assertEquals("Username is not correctly formatted, please ensure it contains an underscore and is no more than five characters in length.", login.checkUserName("kyle!!!!!!!"));
    }

    
    public void testPasswordCorrect() {

        assertEquals("Password successfully captured.", login.checkPasswordComplexity("Ch&&sec@ke99!"));
    }
    
    
    public void tsetPasswordIncorrect(){
        assertEquals("Password is not correctly formatted, please ensure it contains at least 8 characters, a capital letter, a number and a special character.", login.checkPasswordComplexity("Password"));
    }

    
    public void testPhoneCorrect() {

        assertEquals("Cellphone number successfully added.", login.checkCellPhoneNumber("+27838968976"));
    }
    
    
    public void testPhoneIncorrect(){
        assertEquals("Cellphone number incorrectly formatted or does not contain international code.", login.checkCellPhoneNumber("08966553"));
    }

    // assertTrue / False LOGIN

    
    public void testLoginSuccess() {

        login.registerUser( "Jay_", "Jason@123", "+27831234567");

        assertTrue(
            login.loginUser("Jay_", "Jason@123")
        );
    }

    
    public void testLoginFail() {

        login.registerUser("Jay_", "Jason@123", "+27831234567");

        assertFalse(
            login.loginUser("Jay_", "wrong123")
        );
    }

    private void assertEquals(String username_is_not_correctly_formatted_pleas, String checkUserName) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void assertFalse(boolean loginUser) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void assertTrue(boolean loginUser) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}